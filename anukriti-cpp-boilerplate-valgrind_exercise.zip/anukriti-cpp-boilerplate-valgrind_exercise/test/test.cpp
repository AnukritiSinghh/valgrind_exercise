#include <gtest/gtest.h>

TEST(dummy, should_pass) {
  EXPECT_EQ(1, 1);
}
